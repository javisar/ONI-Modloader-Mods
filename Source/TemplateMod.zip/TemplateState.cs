﻿using System.Collections.Generic;

namespace $safeprojectname$
{
    public class TemplateState
    {
        public bool Enabled { get; set; } = true;

        public int Parameter { get; set; } = 512;
    }
}